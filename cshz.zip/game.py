import pygame
import math
import random
import socket
import threading
import pickle
import time
import sys

pygame.init()
pygame.font.init()
pygame.mixer.init()

font = pygame.font.SysFont("Arial", 16)

WIDTH, HEIGHT = 900, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Shooter")
clock = pygame.time.Clock()

PORT = 5555
UDP_PORT = 50000

# ---------------- ARGS ----------------
if len(sys.argv) > 2:
    SERVER_IP = sys.argv[1]
    PLAYER_NAME = sys.argv[2]
else:
    SERVER_IP = input("IP: ")
    PLAYER_NAME = input("Nick: ")

IS_SERVER = SERVER_IP.lower() == "host"

# ---------------- ASSETS ----------------
gun_img = pygame.image.load("assets/gun.png").convert_alpha()
gun_img = pygame.transform.scale(gun_img, (120, 60))

shoot_sound = pygame.mixer.Sound("assets/shoot.wav")
shoot_sound.set_volume(0.5)

# ---------------- GAME STATE ----------------
player_id = random.randint(1000, 9999)
player_pos = [WIDTH // 2, HEIGHT // 2]

players = {}
player_names = {}
bullets = []

players[player_id] = player_pos
player_names[player_id] = PLAYER_NAME

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
lock = threading.Lock()

recoil = 0.05

# 🔥 автострельба настройки
fire_delay = 200   # меньше = быстрее стрельба
last_shot_time = 0

# ---------------- BULLET ----------------
class Bullet:
    def __init__(self, x, y, dx, dy, owner):
        self.x = x
        self.y = y
        self.dx = dx
        self.dy = dy
        self.owner = owner
        self.speed = 10

    def update(self):
        self.x += self.dx * self.speed
        self.y += self.dy * self.speed

# ---------------- UTILS ----------------
def get_angle(px, py, mx, my):
    return math.degrees(math.atan2(my - py, mx - px))

def shoot():
    global recoil
    recoil = 10
    shoot_sound.play()

# ---------------- SERVER ----------------
if IS_SERVER:
    sock.bind(("0.0.0.0", PORT))
    sock.listen()

    udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

    def broadcast():
        while True:
            udp.sendto(f"CS_SERVER:{PORT}".encode(), ("255.255.255.255", UDP_PORT))
            time.sleep(2)

    threading.Thread(target=broadcast, daemon=True).start()

    def handle(conn):
        global players, bullets, player_names

        data = conn.recv(4096)
        info = pickle.loads(data)

        player_names[info["id"]] = info["name"]

        while True:
            try:
                data = conn.recv(4096)
                if not data:
                    break

                msg = pickle.loads(data)

                with lock:
                    if "pos" in msg:
                        players[msg["id"]] = msg["pos"]

                    if "bullet" in msg:
                        x, y, dx, dy, owner = msg["bullet"]
                        bullets.append(Bullet(x, y, dx, dy, owner))

                conn.sendall(pickle.dumps({
                    "players": players,
                    "names": player_names,
                    "bullets": [(b.x, b.y) for b in bullets]
                }))
            except:
                break

    def accept():
        while True:
            conn, _ = sock.accept()
            threading.Thread(target=handle, args=(conn,), daemon=True).start()

    threading.Thread(target=accept, daemon=True).start()

else:
    sock.connect((SERVER_IP, PORT))
    sock.send(pickle.dumps({
        "id": player_id,
        "name": PLAYER_NAME
    }))

# ---------------- MAIN LOOP ----------------
running = True
remote_bullets = []

while running:
    clock.tick(60)
    screen.fill((20, 20, 20))

    mx, my = pygame.mouse.get_pos()
    current_time = pygame.time.get_ticks()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 🔥 AUTO FIRE (зажал ЛКМ)
    mouse_pressed = pygame.mouse.get_pressed()[0]

    if mouse_pressed:
        if current_time - last_shot_time >= fire_delay:
            last_shot_time = current_time

            shoot()

            angle = math.atan2(my - player_pos[1], mx - player_pos[0])
            dx = math.cos(angle)
            dy = math.sin(angle)

            if IS_SERVER:
                bullets.append(Bullet(player_pos[0], player_pos[1], dx, dy, player_id))
            else:
                sock.send(pickle.dumps({
                    "bullet": (player_pos[0], player_pos[1], dx, dy, player_id)
                }))

    # ---------------- MOVEMENT ----------------
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w]: player_pos[1] -= 4
    if keys[pygame.K_s]: player_pos[1] += 4
    if keys[pygame.K_a]: player_pos[0] -= 4
    if keys[pygame.K_d]: player_pos[0] += 4

    # ---------------- SYNC ----------------
    try:
        if IS_SERVER:
            players[player_id] = player_pos
        else:
            sock.send(pickle.dumps({"id": player_id, "pos": player_pos}))
            data = sock.recv(8192)
            state = pickle.loads(data)
            players = state["players"]
            player_names = state["names"]
            remote_bullets = state["bullets"]
    except:
        pass

    # ---------------- DRAW PLAYERS ----------------
    for pid, pos in players.items():
        pygame.draw.circle(screen, (0, 200, 255), (int(pos[0]), int(pos[1])), 12)

        name = player_names.get(pid, "Unknown")
        text = font.render(name, True, (255, 255, 255))
        screen.blit(text, (pos[0] - text.get_width() // 2, pos[1] - 25))

    # ---------------- DRAW BULLETS ----------------
    if IS_SERVER:
        for b in bullets:
            b.update()
            pygame.draw.circle(screen, (255, 255, 0), (int(b.x), int(b.y)), 4)
    else:
        for b in remote_bullets:
            pygame.draw.circle(screen, (255, 255, 0), (int(b[0]), int(b[1])), 4)

    # ---------------- DRAW GUN ----------------
    angle = get_angle(player_pos[0], player_pos[1], mx, my)
    rotated_gun = pygame.transform.rotate(gun_img, -angle)

    offset = 20
    gx = player_pos[0] - rotated_gun.get_width() // 2 + math.cos(math.radians(angle)) * offset
    gy = player_pos[1] - rotated_gun.get_height() // 2 + math.sin(math.radians(angle)) * offset

    if recoil > 0:
        recoil -= 1
        gx -= math.cos(math.radians(angle)) * recoil
        gy -= math.sin(math.radians(angle)) * recoil

    screen.blit(rotated_gun, (gx, gy))

    pygame.display.flip()

pygame.quit()